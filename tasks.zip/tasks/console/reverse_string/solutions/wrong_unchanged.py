s = input()
print(s)
