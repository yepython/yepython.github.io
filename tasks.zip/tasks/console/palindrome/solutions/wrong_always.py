s = input()
print("паліндром")
